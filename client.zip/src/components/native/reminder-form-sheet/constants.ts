export const WEEK_DAYS = [
  { key: "mon", label: "��" },
  { key: "tue", label: "��" },
  { key: "wed", label: "��" },
  { key: "thu", label: "��" },
  { key: "fri", label: "��" },
  { key: "sat", label: "��" },
  { key: "sun", label: "��" },
] as const;

export const MONTH_DAYS = Array.from({ length: 31 }, (_, index) => index + 1);

export type ReminderMode = "week" | "month";
