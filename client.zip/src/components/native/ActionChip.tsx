﻿import type { ReactNode } from "react";
import { Pressable, Text } from "react-native";

import { appPalette } from "@/theme/palette";

type ActionChipTone = "primary" | "secondary" | "success" | "danger";

const toneStyles: Record<ActionChipTone, { backgroundColor: string; textColor: string; borderColor?: string }> = {
  primary: {
    backgroundColor: appPalette.semantic.infoSurface,
    textColor: appPalette.semantic.infoText,
    borderColor: appPalette.semantic.infoBorder,
  },
  secondary: {
    backgroundColor: appPalette.surface.background,
    textColor: appPalette.semantic.text,
    borderColor: appPalette.semantic.borderSubtle,
  },
  success: {
    backgroundColor: appPalette.semantic.successSurface,
    textColor: appPalette.semantic.successText,
    borderColor: appPalette.semantic.successBorder,
  },
  danger: {
    backgroundColor: appPalette.semantic.dangerSurface,
    textColor: appPalette.semantic.dangerText,
    borderColor: appPalette.semantic.dangerBorder,
  },
};

export function ActionChip({
  children,
  onPress,
  tone = "secondary",
}: {
  children: ReactNode;
  onPress?: () => void;
  tone?: ActionChipTone;
}) {
  const palette = toneStyles[tone];

  return (
    <Pressable
      onPress={onPress}
      style={{
        backgroundColor: palette.backgroundColor,
        borderRadius: 10,
        paddingHorizontal: 12,
        paddingVertical: 10,
        borderWidth: 1,
        borderColor: palette.borderColor ?? palette.backgroundColor,
      }}
    >
      <Text style={{ color: palette.textColor, fontWeight: "500", fontSize: 12, lineHeight: 18, fontFamily: "Montserrat" }}>{children}</Text>
    </Pressable>
  );
}
